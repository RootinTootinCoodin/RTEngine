function TEMPLATE()
    local table = {}
--Do not touch
    table["UUID"] = 0
--

    function table:Start()
    end
    function table:Update()
    end
    return table
end